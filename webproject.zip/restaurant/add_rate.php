<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rating System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/css/bootstrap.min.css" integrity="sha384-SI27wrMjH3ZZ89r4o+fGIJtnzkAnFs3E4qz9DIYioCQ5l9Rd/7UAa8DHcaL8jkWt" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
    <style>
        /* Custom styles for rating system */
        .container{
            margin-top: 50px;
            text-align: center;
        }
        .rateyo {
            margin-bottom: 20px;
        }
        .result {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }
        body {
            background-color: #f0f0f0;
            color: #333;
        }
        input[type="text"] {
            background-color: #ebf0f5;
            border: 1px solid black;
            color: #000000;
            padding: 10px 20px;
            border-radius: 5px;
            margin: 20px;
            cursor: pointer;
            margin-top: 10px;
        }
        input[type="text"]:focus {
            outline: none;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
            transition: 0.5s;
        }
        input[type="submit"]{
            background-color: #9851f5;
            color: rgb(255, 255, 255);
            border: none;
            border-radius: 10px;
            padding: 10px;
            font-size: 15px;
        }
    </style>
</head>
<body>
<div class="container">
    <h3>Rating System | codingmanish</h3>

    <div class="row justify-content-center">
        <div class="col-md-6">

            <form action="add_rate.php" method="post">

                <div>
                    <label>Name : </label>
                    <input type="text" name="name">
                </div>

                <div class="rateyo" id="rating"
                     data-rateyo-rating="4"
                     data-rateyo-num-stars="5"
                     data-rateyo-score="3">
                </div>

                <span class='result'>0</span>
                <input type="hidden" name="rating">

                <input type="submit" name="add">

            </form>
        </div>
    </div>

    <div class="row justify-content-center mt-4">
        <div class="col-md-6">
            <!-- Display previous comments here -->
            <?php
            require 'db_connection.php';

            $sql = "SELECT * FROM ratee";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<div class='alert alert-primary' role='alert'>";
                    echo "Name: " . $row["name"] . " - Rating: " . $row["rate"];
                    echo "</div>";
                }
            } else {
                echo "No previous comments.";
            }

            mysqli_close($conn);
            ?>
        </div>
    </div>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>

<script>
    $(function () {
        $(".rateyo").rateYo().on("rateyo.change", function (e, data) {
            var rating = data.rating;
            $(this).parent().find('.score').text('score :' + $(this).attr('data-rateyo-score'));
            $(this).parent().find('.result').text('rating :' + rating);
            $(this).parent().find('input[name=rating]').val(rating); //add rating value to input field
        });
    });
</script>

</body>
</html>
