let ratings = {
    menu1: 0,
    menu2: 0,
    menu3: 0,
    menu4: 0,
    menu5: 0,
    menu6: 0,
    menu7: 0,
    menu8: 0,
    menu9: 0,
    menu10: 0,
    menu11: 0,
    menu12: 0,
    menu13: 0,
    menu14: 0,
    menu15: 0,
    menu16: 0,
    menu17: 0,
    menu18: 0,
    menu19: 0,
    menu20: 0,
    menu21: 0,
    menu22: 0,
    menu23: 0,
    menu24: 0,
    menu25: 0,
    menu26: 0,
    menu27: 0
};

function openModal(menuItemId) {
    document.getElementById('myModal').style.display = "block";
    document.getElementById('menuItemId').value = menuItemId; // Set the menu item id in the hidden input field
}

function closeModal() {
    document.getElementById('myModal').style.display = "none";
}

function rate(num) {
    rating = num;
    const stars = document.querySelectorAll('.modal-content .stars span');
    stars.forEach((star, index) => {
        if (index < num) {
            star.classList.add('active');
        } else {
            star.classList.remove('active');
        }
    });
}

function submitRating() {
    const menuItemId = document.getElementById('menuItemId').value; // Get the menu item id from the hidden input field
    const totalRating = calculateTotalRating(menuItemId);
    document.getElementById('totalRating_' + menuItemId).textContent = totalRating.toFixed(1);

    // Send rating data to the backend
    const formData = new FormData();
    formData.append('menuItemId', menuItemId);
    formData.append('rating', rating);

    fetch('http://localhost/phpmyadmin/index.php?route=/sql&pos=0&db=restaurent&table=login', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log('Rating submitted successfully:', data);
    })
    .catch(error => {
        console.error('Error submitting rating:', error);
    });

    closeModal();
}

function calculateTotalRating(menuItemId) {
    let total = 0;
    const ratingsCount = Object.keys(ratings).length;
    let totalRatings = 0;

    for (let key in ratings) {
        if (key !== menuItemId) {
            total += ratings[key];
            if (ratings[key] > 0) {
                totalRatings++;
            }
        }
    }

    const averageRating = total / totalRatings;
    return isNaN(averageRating) ? 0 : averageRating;
}

function submitComment() {
    const menuItemId = document.getElementById('menuItemId').value;
    const comment = document.getElementById('comment').value;

    // Send comment data to the backend
    const formData = new FormData();
    formData.append('menuItemId', menuItemId);
    formData.append('comment', comment);

    fetch('http://your-backend-url.com/submitComment', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log('Comment submitted successfully:', data);
        updatePreviousComments(comment);
    })
    .catch(error => {
        console.error('Error submitting comment:', error);
    });
}

function updatePreviousComments(comment) {
    // Display the new comment in the frontend immediately without waiting for response from backend
    const previousCommentsContainer = document.getElementById('previousComments');
    const newComment = document.createElement('div');
    newComment.textContent = comment;
    previousCommentsContainer.appendChild(newComment);
}
