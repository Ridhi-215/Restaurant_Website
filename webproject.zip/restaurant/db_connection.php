<?php


$servername = "localhost";//Server Name
$username = "root";//Server User Name
$password = "";//Server Password
$dbname = "restaurant";//Database Name

//Create DB Connection
$conn = mysqli_connect($servername,$username,$password,$dbname);

?>