<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>restaurant Rating</title>
    
    <!-- fontawesome link here -->
    <link rel="stylesheet" href="fontawesome-free-5.15.3-web/css/all.min.css">
    
    <!-- style link here -->
    <link rel="stylesheet" href="style.css">
    

</head>
<body>
    
    <header class="header">
        <nav class="navbar">
            <a href="#home">Home</a>
             <a href="#gallery">Gallery</a>
            <a href="#about">About</a>
            <a href="#menu">Restaurant</a>
        </nav>

        <div class="icons">
            <div id="menu-bar" class="fas fa-bars"></div>
            <a class="contact-btn" href="login.html">Login</a>
        </div>

    </header>

    <section id="home" class="home">


        <div class="main-home">
            <div class="home-inner-content">
                <div class="home-image">
                <img src="images/background content.png" alt="">
                </div>
            </div>

            <div class="home-inner-content">
                <div class="home-text-content">
                <h1>BLUE MOON</h1>
                <p>Welcome to Blue Moon , your go-to destination for discovering and rating the best restaurants in <b>Vijayawada</b> ! .Join our community of food lovers and start discovering your next culinary delight today!</p>
                <a href="add-restaurant.html" class="add-restaurant-btn">Add Restaurant</a>

                </div>
            </div>
        </div>

    </section>

    <section id="gallery" class="gallery">

        <h1>Gallery</h1>

        <div class="main-gallery">
            <div class="inner-gallery">
                <div class="gallery-image">
                    <img src="https://e2055c0b26b4b719ed7c.cdn6.editmysite.com/uploads/b/e2055c0b26b4b719ed7c69c73e4acda6daaa410eaef83dd382ade3a54a1d7de5/menu%20hero%20shot%20smaller_1639418845.jpg?width=2400&optimize=medium&height=480&fit=cover&dpr=2.625" alt="">
                </div>
            </div>

            <div class="inner-gallery">
                <div class="gallery-image">
                    <img src="https://res.cloudinary.com/rainforest-cruises/images/c_fill,g_auto/f_auto,q_auto/w_1120,h_732,c_fill,g_auto/v1661347444/india-food-butter-chicken/india-food-butter-chicken-1120x732.jpg" alt="">
                </div>
            </div>

            <div class="inner-gallery">
                <div class="gallery-image">
                    <img src="https://res.cloudinary.com/hz3gmuqw6/image/upload/c_fill,q_60,w_750,f_auto/25-butter-chicken-murgh-makhani-canva-phpcxhfCA" alt="">
                </div>
            </div>

            <div class="inner-gallery">
                <div class="gallery-image">
                    <img src="https://www.thespruceeats.com/thmb/hqqNrNhIpqPqV2u0T0K-IUzUsEo=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/SES-cuisine-of-north-india-1957883-d32a933f506d43f59ac38a8eb956884a.jpg" alt="">
                </div>
            </div>

            <div class="inner-gallery">
                <div class="gallery-image">
                    <img src="https://images.everydayhealth.com/images/diet-nutrition/healthy-dishes-to-order-at-indian-restaurants-1440x810.jpg" alt="">
                </div>
            </div>

            <div class="inner-gallery">
                <div class="gallery-image">
                    <img src="https://img.taste.com.au/iCntbupq/w720-h480-cfill-q80/taste/2019/04/indian-lentil-and-egg-curry-148613-1.jpg" alt="">
                </div>
            </div>
        </div>
    </section>


    <section id="about" class="about">
        <div class="main-about">
            <div class="about-content">
                <div class="about-inner-content">
                    <img class="myimageabout" src="images/About us.png" alt="">
                </div>
            </div>

            <div class="about-content">
                <div class="about-inner-content">
                    <div class="about-text-content">
                        <h1>About us</h1>
                        <p> Welcome to Blue Moon - your destination for discovering and rating restaurants in Vijayawada!
                            At Blue Moon, we're passionate about connecting food enthusiasts with great dining experiences. Explore our curated selection of restaurants, read reviews from fellow diners, and share your own ratings.
                            Join us in celebrating the culinary diversity of Vijayawada. Discover, rate, and share your favorite dining spots with Blue Moon!</p>

                    </div>
                </div>
            </div>
        </div>
    </section>
   

    <section id="menu" class="our-menu-food">
        <h1> RESTAURANTS</h1>

        <div class="main-menu-food">
            <div class="inner-menu-food">
                <div class="menu-food-content">
                    <img src="https://lh5.googleusercontent.com/p/AF1QipNxY4oTT9QNBkjkVMLMumfs52Vm559rIm8gml-e=w408-h271-k-no" alt="">

                    <div class="menu-food-text">
                        <h2>Deepika Reastaurant</h2>
                        <p> Service options: Has all you can eat · Has outdoor seating · Serves vegan dishes</p>
                        <div class="ratings">
                            <span class="rating">Ratings :   </span>
                            <span class="stars"></span>
                        </div>
                        <a href="page1.html" class="more-button">More</a>
                    </div>
                </div>
            </div>

            <div class="inner-menu-food">
                <div class="menu-food-content">
                    <img src="https://lh5.googleusercontent.com/p/AF1QipPPpbI-NpKZQfQR7qYxokG1_WDE_wSmly_qCp6O=w408-h272-k-no" alt="">

                    <div class="menu-food-text">
                        <h2>RASOIE</h2>
                        <p> Service options: Has all you can eat · Serves vegan dishes · Good for watching sport </p>
                        <div class="ratings">
                            <span class="rating">Ratings :   </span>
                            <span class="stars"></span>
                        </div>
                        <a href="page2.html" class="more-button">More</a>
                    </div>
                </div>
            </div>

            <div class="inner-menu-food">
                <div class="menu-food-content">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT3S7-tzqWk9VAndJ6ZIS0E7TUaPrwreSKVKbZcHkkcB9vjvcX9TLPotPwCoC0wmZ0bprg&usqp=CAU" alt="">

                    <div class="menu-food-text">
                        <h2>United Telugu Kitchens (UTK)</h2>
                        <p> Service options: Has all you can eat · Serves vegan dishes · Has live music</p>
                        <div class="ratings">
                            <span class="rating">Ratings :   </span>
                            <span class="stars"></span>
                        </div>
                        <a href="page3.html" class="more-button">More</a>
                    </div>
                </div>
            </div>
            <div class="inner-menu-food">
                <div class="menu-food-content">
                    <img src="images/menu3.png" alt="">

                    <div class="menu-food-text">
                        <h2>Dalchin Restaurant</h2>
                        <p> Service options: Has all you can eat · Has outdoor seating · Serves vegan dishes</p>
                        <div class="ratings">
                            <span class="rating">Ratings :   </span>
                            <span class="stars"></span>
                        </div>
                        <a href="page4.html" class="more-button">More</a>
                    </div>
                </div>
            </div>
            <div class="inner-menu-food">
                <div class="menu-food-content">
                    <img src="images/menu3.png" alt="">

                    <div class="menu-food-text">
                        <h2>GAD Restaurant</h2>
                        <p> Service options: Serves vegan dishes</p>
                        <div class="ratings">
                            <span class="rating">Ratings :   </span>
                            <span class="stars"></span>
                        </div>
                        <a href="page5.html" class="more-button">More</a>
                    </div>
                </div>
            </div>
            <div class="inner-menu-food">
                <div class="menu-food-content">
                    <img src="images/menu3.png" alt="">

                    <div class="menu-food-text">
                        <h2>Little Village</h2>
                        <p> Service options: Has all you can eat · Has outdoor seating · Serves vegan dishes</p>
                        <div class="ratings">
                            <span class="rating">Ratings :   </span>
                            <span class="stars"></span>
                        </div>
                        <a href="page6.html" class="more-button">More</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer id="footer" class="footer">
      
        <div class="footer-info">
            <p>Blue Moon &copy; 2024. All Rights Reserved.</p>
            <p>Contact: +91 6309712626 | Email: gunturridhi@gmail.com</p>
            <p>Contact: +91 8309623821 | Email: arnepallisindhuja@gmail.com</p>
        </div>
    </footer>

<!-- scroll reveal javascript link -->

<script src="https://unpkg.com/scrollreveal"></script>

<!-- javascript link here -->

<script src="script.js"></script>
</body>
</html>